# searchAPI

*    Write a test plan for the documented [iTunes Search API](https://github.com/iappsqainterview/searchAPI/blob/master/API.md)
  

*    Write Java automation that will make requests to this API:<br>
     Include TestNG or JUnit classes with validations for the documented functional test cases
